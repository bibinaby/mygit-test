Folder Structure 

|-> config
|---> Dev
|----> us-west-2
|------> config.json
|------> {Folders structure to replace in artifact folder.}


Template Config File 

```
{
    "isvParameterStore": "<Replace ISV parameter Store>",
    "ssmEKSInputParameter": "<Replace CDK OUT of EKS>",
    "ssmNGInputparameter": "Replace CDK OUT of NG",
    "cnfPackagebucketName": "<Replace Release Bucket Name>",
    "cnfPackageVersionFile": "<Replace Realease package .tgz>",
    "cnfName": "<Replace CNF Name>",
    "cnfInstanceName": "<Replace CNF Instance Name>",
    "deployForCommonFile":false
}






```
`deployForCommonFile` will be key If there is check in buildspec Pipeline will deploy all the environment .If You want to skip any environment add this as false in config file.


