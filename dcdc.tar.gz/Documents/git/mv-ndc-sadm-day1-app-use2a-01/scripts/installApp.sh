#!/bin/bash
source ./scripts/helpers.sh

curl -fsSLo /usr/share/keyrings/kubernetes-archive-keyring.gpg https://packages.cloud.google.com/apt/doc/apt-key.gpg
echo "deb [signed-by=/usr/share/keyrings/kubernetes-archive-keyring.gpg] https://apt.kubernetes.io/ kubernetes-xenial main" | tee /etc/apt/sources.list.d/kubernetes.list
curl -o aws-iam-authenticator https://amazon-eks.s3.${AWS_REGION}.amazonaws.com/1.19.6/2021-01-05/bin/linux/amd64/aws-iam-authenticator
chmod +x aws-iam-authenticator && mv -v aws-iam-authenticator /usr/local/bin
apt-get update
apt-get install --yes jq kubectl apt-transport-https
export AWS_PROFILE=$PROFILE
echo $CDK_OUT_SSM
KubeConfig=` echo $CDK_OUT_SSM | jq '.constructStack | to_entries | map(select(.key | match("EKSClusteraddClusterConfig";"i"))) | map(.value) ' | sed -e 's/\[//' -e 's/\]//' | tr -d '\n' | tr -d '"' `
echo $KubeConfig
bash -c "$KubeConfig"

pwd
cd scripts/scylla/M-W2-PR-001-US-East-2-AZ1-SDB01.1.20.8
helm version
kubectl create ns use2az1n02p1-ns-mv-sdb-001
kubectl apply -f ./scylla-admin.yaml -n use2az1n02p1-ns-mv-sdb-001
validate_running "1 pod for use2az1n02p1-ns-mv-sdb-001 are running" "1" "40" "15" "use2az1n02p1-ns-mv-sdb-001"
kubectl apply -f ./scylla_db.yaml -n use2az1n02p1-ns-mv-sdb-001
validate_running "4 pod for use2az1n02p1-ns-mv-sdb-001 are running" "4" "60" "15" "use2az1n02p1-ns-mv-sdb-001"

kubectl get pods -n use2az1n02p1-ns-mv-sdb-001

