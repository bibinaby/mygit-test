#!/bin/bash

printstatus()
	{
	  if [ $1 -ne 0 ]; then
	    echo ":::::::::::: $2 - FAIL"
	    if [ -z "${3}" ]; then
	      exit 1
	    elif [ "${3}" = "NOEXIT" ];then
	      echo "We should not stop execution for this use case"
	    else
	      exit 1
	    fi
	  else
	    echo ":::::::::::: $2 - PASS"
	  fi
	}

printstage()
  {
    echo ":::::::::::: STAGE: $1"
  }

validate_running()
  {
    local outcome=${1}
    local countRequired=${2}
    #local labels=${3}
    local maxRetries=${3}
    local sleepSeconds=${4}
    local nspc=${5}
    # look for 5 pods with status of "Running" and "specified labels". Wait for sleepSeconds before retrying. Retry for "maxRetries"
    counter=0
    if [ "$countRequired" -eq 0 ]; then
      # this is uninstall request and we are waiting for pods to stop running
      podCount=999
      until [ "$counter" -lt "$maxRetries" ] || [ "$podCount" -gt "$countRequired" ]; do
        podCount=$(kubectl get pods -n ${nspc}  --field-selector=status.phase=="Running" --no-headers|wc -l)
        if [ "$podCount" -lt "$countRequired" ]; then
          echo "Sleep and retry...."
          sleep ${sleepSeconds}
        fi
        ((counter++))
      done
    else
      podCount=0
      until [ "$counter" -gt "$maxRetries" ] || [ "$podCount" -ge "$countRequired" ]; do
        podCount=$(kubectl get pods -n $nspc -o=jsonpath='{range .items[*]}{"\n"}{.metadata.name}{":\t"}{range .status.containerStatuses[*]}{.name}{": "}{.ready}{", "}{end}{end}' --no-headers | grep -v false | grep true | wc -l)
        if [ "$podCount" -lt "$countRequired" ]; then
          echo "Sleep and retry..."
          kubectl get pods -n $nspc
          sleep ${sleepSeconds}
        fi
        ((counter++))
      done
    fi
    if [ "$podCount" -ge "$countRequired" ]; then
      printstatus "0" "CHECK: $outcome"
    else
      printstatus "1" "CHECK: $outcome"
    fi
  }

validate_completed()
{
  local outcome=${1}
  local countRequired=${2}
  local labels=${3}
  local maxRetries=${4}
  local sleepSeconds=${5}
  local nspc=${6}
  counter=0
  until [ "$counter" -gt "$maxRetries" ] || [ "$podCount" -ge "$countRequired" ]; do
    podCount=$(kubectl get pods -n ${nspc} -l app=${labels} --field-selector='status.containerStatuses[0].state.terminated.reason=="Completed"' --no-headers|wc -l)
    if [ "$podCount" -lt "$countRequired" ]; then
      echo "Sleep and retry.."
      sleep ${sleepSeconds}
    fi
    ((counter++))
  done
  if [ "$podCount" -ge "$countRequired" ]; then
    printstatus "0" "CHECK: $outcome"
  else
    printstatus "1" "CHECK: $outcome"
  fi
}

validate_all_containers_ready()
{
  #HINT: If the ask is also the validate that all containers in pods are ready then this may be additionally required.
  kubectl get pods -n cmdb -o=jsonpath='{range .items[*]}{"\n"}{.metadata.name}{":\t"}{range .status.containerStatuses[*]}{.name}{": "}{.ready}{", "}{end}{end}'
}

delete_empty_ns()
{
  local nspc=${1}
      #if there are no more pods in the namespace, then delete the namespace
    podCountInNS=`kubectl get pods -n ${nspc}  --no-headers|wc -l`
    if [ $podCountInNS -eq 0 ]; then
      kubectl delete ns ${nspc} 2>&1 >/dev/null
      printstatus "$?" "DELETE NAMESPACE: ${nspc}" "NOEXIT"
    fi
    printstatus "1" "DELETE NAMESPACE (NOT EMPTY): ${nspc}" "NOEXIT"
}

delete_object()
{
  local type=${1}
  local name=${2}
  local nspc=${3}
  # see if exists
  found=`kubectl get ${type} -n ${nspc} ${name} --no-headers 2>&1 >/dev/null|wc -l`
  if [ found == 1 ];then
    kubectl delete ${type} -n ${nspc} ${name} 2>&1 >/dev/null
    printstatus "$?" "DELETE ${type}: ${name}" "NOEXIT"
  else
    printstatus "0" "DELETE ${type}: ${name} - does not even exist. Nothing to do." "NOEXIT"
  fi
}

delete_pod()
{
  local labels=${1}
  local nspc=${2}
  local type="pod"
  # see if exists
  found=`kubectl get ${type} -n ${nspc} -l ${labels} --no-headers|wc -l`
  if [ found == 1 ];then
    kubectl delete ${type} -n ${nspc} -l ${labels} 2>&1 >/dev/null
    printstatus "$?" "DELETE ${type}: ${name}" "NOEXIT"
  else
    printstatus "0" "DELETE ${type}: ${name} - does not even exist. Nothing to do." "NOEXIT"
  fi
}

validate_curl_response()
{
  local command=${1}
  local allowed_response=${2}

  echo ":::::::::::: COMMAND: kubectl exec -n ${NAMESPACE} ${podForReachabilityTests} -- ${command}"
  response=`eval "kubectl exec -n ${NAMESPACE} ${podForReachabilityTests} -- ${command}"`
  echo ":::::::::::: RESPONSE: $response"
  if [ "$allowed_response" -eq "$response" ]; then
    printstatus "0" "VALIDATE URL RESPONSE"
  else
    printstatus "1" "VALIDATE URL RESPONSE"
  fi

}

