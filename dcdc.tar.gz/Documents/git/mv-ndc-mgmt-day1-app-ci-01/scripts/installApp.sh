#!/bin/sh
#set -e
COUNTER=0
INSTALL_TRACKER=0
ACTION="IGNORE"

cd scripts/ || exit
chmod +x validation.sh

if [ $# -eq 1 ]; then
  export profile_name=$1
else
  export profile_name=$(cat application_config.json|jq .current_profile |tr -d "\"")
fi

echo "Profile is set to : ${profile_name}"
charts_count=$(jq '.profiles.'$profile_name'.charts | length' application_config.json )

if [ $charts_count -lt 1 ];then
  echo "No charts found to deploy"
  exit 1
fi

namespace=$(jq -r '.profiles.'$profile_name'.namespace' application_config.json)

while [ $COUNTER -lt "$charts_count" ];
do
  echo  "######### Iterating over item=$COUNTER from application_config list ############# \n"
  release_name=$(jq -r '.profiles.'$profile_name'.charts['$COUNTER'].release_name' application_config.json)
  chart_key=$(jq -r '.profiles.'$profile_name'.charts['$COUNTER'].chart_key' application_config.json)
  chart_name=$(jq -r '.'$chart_key'' base_config.json)
  values_file=$(jq -r '.profiles.'$profile_name'.charts['$COUNTER'].values' application_config.json)
  delete_flag=$(jq -r '.profiles.'$profile_name'.charts['$COUNTER'].delete' application_config.json)
  helm_params=$(jq -r '.profiles.'$profile_name'.charts['$COUNTER'].helm_params' application_config.json)
  helm status ${release_name} -n ${namespace}

  if [ $? -eq 0 ];then
    if [ "$delete_flag" = "true" ];then
      helm delete ${release_name} -n ${namespace}
      ACTION="INSTALL"
    else
      echo "Skipping install for ${chart_name}"
    fi
  else
    ACTION="INSTALL"
  fi

  if [ "$ACTION" = "INSTALL" ];then
    echo helm upgrade --install  ${release_name} ${chart_name} -f ${values_file} -n ${namespace} ${helm_params}  --create-namespace
    helm upgrade --install  ${release_name} ${chart_name} -f ${values_file} -n ${namespace} ${helm_params}  --create-namespace
    STATUS=$?
    if [ $STATUS -ne 0 ]; then
      INSTALL_TRACKER=$STATUS
    fi
  fi
  sleep 3
  COUNTER=$((COUNTER+1))
done

if [ $INSTALL_TRACKER -ne 0 ];then
  echo "One more installation of charts has failed.Won't go to validation stage"
  exit 1
fi

echo  "\n######### Moving to Validation Stage #################"

./validation.sh -s 10 -i 5 -n ${namespace}





