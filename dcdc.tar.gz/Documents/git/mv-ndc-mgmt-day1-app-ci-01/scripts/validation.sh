#!/bin/bash
# printenv
# echo "my name: $MY_POD_NAME"

## Deafult Value
iteration=10
time_to_pause=30
wait=0
cmd_to_check_pod="kubectl get pods"
exclude=""
proceed="no"
printusage()
{
      echo "usage: $0 [-s|--sleep] [-i|--iteration] [-l|--label] [-n|--namespace] [-e|--exclude] [-w|--wait] [--continue]"
      echo "-s|--sleep      : Number of seconds to pause before checking the status again. Default 30 sec"
      echo "-i|--iteration  : Number of time to check. Default 10 "
      echo "-l|--label      : Filter based on label. Default there is no filter"
      echo "-n|--namespace  : Namespace to search. Default is \"default\" namespace"
      echo "-w|--wait       : Number of seconds to wait before starting to check. Default is 0 sec"
      echo "-e|--exclude    : provide a pattern to excldue. For example -e \"abcd|xyz|dontmatch\" . the script will ignore pods matching this naming pattern"
      echo "--continue      : Continue even with error"
}
## Processing Parameters
while [[ $# -gt 0 ]]
do
  key="$1"
  case $key in
      -i|--iteration)
      iteration="$2"
      shift 2
      ;;
      --continue)
      proceed="yes"
      shift 1
      ;;
      -e|--exclude)
      exclude="$2"
      echo "exl is set to $exclude"
      shift 2
      ;;
      -w|--wait)
      wait="$2"
      shift 2
      ;;
      -s|--sleep)
      time_to_pause="$2"
      shift # past argument
      shift # past value
      ;;
      -l|--label)
      label="$2"
      cmd_to_check_pod="${cmd_to_check_pod} -l ${label}"
      shift # past argument
      shift # past value
      ;;
      # -r|--release)
      # release="$2"
      # cmd_to_check_pod="${cmd_to_check_pod} -r ${release}"
      # shift # past argument
      # shift # past value
      # ;;
      -h|--help)
      printusage
      exit
      ;;
      -n|--namespace)
      namespace="$2"
      cmd_to_check_pod="${cmd_to_check_pod} -n ${namespace}"
      shift # past argument
      shift # past value
      ;;
      *)    # unknown option
      printusage
      exit
      ;;
  esac
done

if [[ "${proceed}" == "yes" ]]; then
  exit_code=0
else
  exit_code=1
fi

echo "The following value is set:"
echo "----------------------------------"
printf "iteration: $iteration\nsleep: $time_to_pause\nwait: $wait \nproceed on fail: $proceed\n"

# if [[ -z $release ]]; then
#   echo "release: Not set"
#   cmd_to_check_pod="kubectl get pods -n $namespace"
# else
#   echo "release: $release"
#   cmd_to_check_pod="kubectl get pods -n $namespace -l release=${release}"
# fi



if [[ !  -z ${exclude} ]]; then
  echo "kubectl command to execute for checking the status: \"$cmd_to_check_pod\" |egrep -v ${exclude}"
else
  echo "kubectl command to execute for checking the status: \"$cmd_to_check_pod\" "
fi
echo "----------------------------------"
temp_file_name='/tmp/all_pod.txt'
temp_file_name1='/tmp/all_pod1.txt'
>${temp_file_name}
>${temp_file_name1}




#cmd_to_check_pod="cat /tmp/abc"
initial_snapshot()
{
  # printf "Checking curent status\n"
  if [[ !  -z ${exclude} ]]; then
    $cmd_to_check_pod --no-headers |egrep -v "${exclude}" > $temp_file_name1
  else
    $cmd_to_check_pod --no-headers > $temp_file_name1
  fi
  # cat /tmp/aa > $temp_file_name1
  if [[ $? -ne 0 ]]; then
    echo "Not able to execute $cmd_to_check_pod. Exiting..."
    exit 1
  fi
}

take_snapshot()
{
  if [[ !  -z ${exclude} ]]; then
    $cmd_to_check_pod --no-headers |egrep -v "${exclude}" > $temp_file_name
  else
    $cmd_to_check_pod --no-headers > $temp_file_name
  fi
  if [[ $? -ne 0 ]]; then
    echo "Not able to execute $cmd_to_check_pod. Exiting..."
    exit 1
  fi
}
get_total_container()
{
  local total_container_present=$(cat $temp_file_name |awk '$1 == "'$1'" {print $2}' |awk -F"/" '{print $2}')
  echo $total_container_present
}

get_running_containter()
{
  local total_container_running=$(cat $temp_file_name |awk '$1 == "'$1'" {print $2}' |awk -F"/" '{print $1}')
  echo $total_container_running
}

get_pod_status()
{
  local pod_status=$(cat $temp_file_name |awk '$1 == "'$1'" {print $3}')
  echo $pod_status
}

check_for_running_or_complete()
{
  cnt=1
  while [[ $cnt -le $iteration ]]; do
    take_snapshot
    echo ""
    get_stat_pod "$pod_name"
    if [[ "${pod_status}" == "" ]]; then
      printlog "PASSED. Pod does not exist anymore"
      status="completed"
      break
    fi
    # cat $temp_file_name # can be deleted later
    if [[ ${pod_status} != "Running" && ${pod_status} != "Completed" ]]; then
      printlog "NOT PASSED. Iteration $cnt"
      # echo "Waiting for $time_to_pause seconds..."
      sleep $time_to_pause
      let "cnt+=1"
    elif [[ ${pod_status} == "Completed" ]]; then
      printlog "PASSED"
      status="completed"
      break
    else
      printlog "RUNNING"
      status="running"
      break
    fi
    if [[ $cnt -gt $iteration ]]; then
      printlog "FAILED"
      exit ${exit_code}
    fi
  done
}

printlog()
{
  printf "%-45s : %-10s : Total container %-2s : Running container %-2s -- %-12s\n"  "$pod_name" "$pod_status" "$total_container" "$running_container" "$1"
}
check_for_completion()
{
  if [[ $total_container -eq $running_container ]]; then
    printlog "PASSED"
  else
    cnt=1
    while [[ $cnt -le $iteration ]]; do
      take_snapshot
      get_stat_pod "$pod_name"

      if [[ "${pod_status}" == "" ]]; then
        printlog "PASSED. Pod does not exist anymore"
        status="success"
        break
      fi

      if [[ $total_container -eq $running_container ]]; then
        printlog "PASSED"
        status="success"
        break
      else
        printlog "NOT PASSED. Iteration $cnt"
        status="fail" # it can be deleted
        # echo "Waiting for $time_to_pause seconds..."
        sleep $time_to_pause
        let "cnt+=1"
      fi
      if [[ $cnt -gt $iteration ]]; then
        printlog "FAILED"
        status="fail"  # not needed
        exit ${exit_code}
      fi
    done
  fi
}

get_stat_pod()
{
  total_container=$(get_total_container $1)
  running_container=$(get_running_containter $1)
  pod_status=$(get_pod_status $1)
}

## MAIN

echo "Waiting for ${wait} seconds before checking"
sleep ${wait}

initial_snapshot
take_snapshot

if [ $(cat $temp_file_name |wc -l |tr -d " ") -eq 0 ]; then
  echo "No PODs found"
  exit
fi
# echo "Output of $cmd_to_check_pod"
# cat $temp_file_name

# sleep $time_to_pause
while IFS= read -r a ; do

  pod_name=$(echo $a|awk '{print $1}')
  ## check if pod still exists
  pod_exists=$(cat $temp_file_name |awk '$1 == "'$pod_name'" {print $1}')
  if [[ "${pod_exists}" != "${pod_name}" ]]; then
    printlog "PASSED. Pod does not exist anymore"
    continue
  fi

  get_stat_pod "$pod_name"

  if [[ "$pod_status" == "Completed" ]]; then
    printlog "PASSED"
    continue
  elif [[ "$pod_status" == "Running" ]]; then
    check_for_completion "$pod_name"
  else
    check_for_running_or_complete "$pod_name"
    if [[ ${status} == "running" ]]; then
      check_for_completion "$pod_name"
    fi
  fi
done < $temp_file_name1

