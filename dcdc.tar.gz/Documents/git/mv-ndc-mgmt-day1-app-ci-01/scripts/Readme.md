Add Scripts for the App Pipeline
