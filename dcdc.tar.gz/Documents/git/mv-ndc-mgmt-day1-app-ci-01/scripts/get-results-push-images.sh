#! /bin/sh
set -e

export DEV_ROLE_ARN=$1
echo $DEV_ROLE_ARN
export CENTRAL_ROLE_ARN=$2
echo $CENTRAL_ROLE_ARN
export ISV_NAME=$3
echo $ISV_NAME
export CODEBUILD_SRC_DIR=$4
echo $CODEBUILD_SRC_DIR
export prisma_access=$5
echo $prisma_access

# Get the list of images from Helm values file
# For Non Nokia change the chart and values file location in the helm template command below
# Ex helm template $CODEBUILD_SRC_DIR/scripts/Artifacts/mediation-10.5-main/ --values $CODEBUILD_SRC_DIR/scripts/Artifacts/mediation-10.5-main/values-dev.yaml

if [ $ISV_NAME == nk ];
then
    # #Install Helmfile
    # pip install git-remote-codecommit
    # git clone codecommit::us-west-2://Dish-CDK-Modules -b tool-scripts
    # #Copy helmfile and yq binary
    # chmod +x Dish-CDK-Modules/scripts/helmfile
    # cp Dish-CDK-Modules/scripts/helmfile /usr/bin/helmfile
    # chmod +x ./*.sh
    ## NOTE - helmfile will be available from previous stage
    ls helmfile
    chmod +x helmfile
    cp helmfile /usr/bin/helmfile
    helmfile version
    cat values.yaml
    echo "Extracting images for Nokia ISV"
    helm_image=$(cat installApp.sh |grep -v "#" |grep helmfile | grep sync | while read -r helm_sync; do  echo ${helm_sync} | sed -e 's/sync/template/g';done | while read -r helm_template; do
    ($helm_template) | grep image: | sed -e 's/[ ]*image:[ ]*//' -e 's/"//g' |awk -F '#' '{print $1}' | sort -u
    done)
    echo $helm_image
else
    echo "Extracting images for Non-Nokia ISV"
    helm_image=$(helm template $CODEBUILD_SRC_DIR/scripts/Artifacts/mediation-10.5-main/ --values $CODEBUILD_SRC_DIR/scripts/Artifacts/mediation-10.5-main/values-dev.yaml | grep image: | sort -u)
    echo $helm_image
fi

cd $CODEBUILD_SRC_DIR/scripts

#Setting Profile as CICD Dev Account
CREDS=$(aws sts assume-role --role-arn $DEV_ROLE_ARN --role-session-name $(date '+%Y%m%d%H%M%S%3N') --duration-seconds 3600 --query '[Credentials.AccessKeyId,Credentials.SecretAccessKey,Credentials.SessionToken]' --output text)
aws configure --profile devcicd set region "us-west-2"
aws configure --profile devcicd set output "json"
aws configure --profile devcicd set aws_secret_access_key "$(echo $CREDS | cut -d' ' -f2)"
aws configure --profile devcicd set aws_access_key_id "$(echo $CREDS | cut -d' ' -f1)"
aws configure --profile devcicd set aws_session_token "$(echo $CREDS | cut -d' ' -f3)"

#Setting Profile as CICD Central Account
CREDS=$(aws sts assume-role --role-arn $CENTRAL_ROLE_ARN --role-session-name $(date '+%Y%m%d%H%M%S%3N') --duration-seconds 3600 --query '[Credentials.AccessKeyId,Credentials.SecretAccessKey,Credentials.SessionToken]' --output text)
aws configure --profile centralcicd set region "us-west-2"
aws configure --profile centralcicd set output "json"
aws configure --profile centralcicd set aws_secret_access_key "$(echo $CREDS | cut -d' ' -f2)"
aws configure --profile centralcicd set aws_access_key_id "$(echo $CREDS | cut -d' ' -f1)"
aws configure --profile centralcicd set aws_session_token "$(echo $CREDS | cut -d' ' -f3)"

parameter_value=$(aws ssm --region us-west-2 --profile devcicd get-parameter --with-decryption --name $prisma_access | jq -r .Parameter.Value)
prisma_registry_url=$(echo $parameter_value | jq -r .prisma_registry_url)
prisma_registry_access=$(echo $parameter_value | jq -r .prisma_registry_access)
prisma_registry_secret=$(echo $parameter_value | jq -r .prisma_registry_secret)
cicd_central_account=$(echo $parameter_value | jq -r .cicd_central_account)
dev_ecr_url=$(echo $parameter_value | jq -r .dev_ecr_url)

for a in $helm_image; do
    echo $a
    image=$(echo $a | grep 155880749572.dkr.ecr.us-west-2.amazonaws.com)
    echo $image

    images=$(echo $a | sed -e 's/[ ]*image:[ ]*//' -e 's/"//g')
    echo "Image is $images"

    export authentication_url="$prisma_registry_url/authenticate"
    get_token=$(curl --location --request POST "$authentication_url" --header 'Content-Type:application/json' --data-raw '{"username":"'"${prisma_registry_access}"'","password":"'"${prisma_registry_secret}"'"}')
    token=$(echo $get_token | jq -r '.token')
    export get_registry_url="$prisma_registry_url/registry?name="
    prisma_repo=$(echo $images | sed 's/^.\{45\}//')
    echo "ECR Repo is $prisma_repo"
    prisma_scan_finding=$(curl --location --request GET "$get_registry_url$images" --header "'Authorization:Bearer' $token")
    vulnerabilityDistribution=$(echo $prisma_scan_finding  | jq  .[].vulnerabilityDistribution)
    echo $vulnerabilityDistribution
    prisma_critical_sev=$(echo $vulnerabilityDistribution | jq -r .critical)
    echo $prisma_critical_sev
    prisma_high_sev=$(echo $vulnerabilityDistribution | jq -r .high)
    echo $prisma_high_sev
    if [ "$prisma_critical_sev" > "0" ];
    then
        if [ "$prisma_high_sev" > "0" ];
        then
            echo "Prisma Scan Report: Critical & High severity vulnerability found in the image $ecr_repo. Number of critical vulnerability = $prisma_critical_sev and high vulnerability = $prisma_high_sev.";
        else
            echo "Prisma Scan Report: Critical severity vulnerability found in the image $ecr_repo. Number of vulnerability = $prisma_critical_sev.";
        fi
    elif [ "$prisma_high_sev" > "0" ];
    then
        echo "Prisma Scan Report: High severity vulnerability found in the image $ecr_repo. Number of vulnerability = $prisma_high_sev.";
    else
        echo "Prisma Scan Report: No Critial or High severity vulnerability found in the image $ecr_repo.";
    fi

    aws ecr get-login-password --region us-west-2 --profile devcicd | docker login --username AWS --password-stdin 155880749572.dkr.ecr.us-west-2.amazonaws.com
    ecr_repo=$(echo $images | sed 's/^.\{45\}//')
    echo "ECR Repo is $ecr_repo"
    repo_name=$(echo $ecr_repo | cut -d':' -f1)
    echo "Repo name is $repo_name"
    tag_name=$(echo $ecr_repo | cut -d':' -f2)
    echo "Tag is $tag_name"
    REPOSITORIES=$(aws ecr --region us-west-2 --profile devcicd describe-repositories | grep .repositoryName | grep $repo_name | awk '{print $2}'| sed 's/"//g'  | sed 's/,//g')
    echo $REPOSITORIES
    scan_finding=$(aws ecr --region us-west-2 --profile devcicd describe-image-scan-findings --repository-name $REPOSITORIES --image-id imageTag=$tag_name | jq -r '.imageScanFindings.findingSeverityCounts')

    critical_sev=$(echo $scan_finding | jq -r .CRITICAL)
    echo $critical_sev
    high_sev=$(echo $scan_finding | jq -r .HIGH)
    echo $high_sev
    if [ "$critical_sev" > "0" ];
    then
        if [ "$high_sev" > "0" ];
        then
        echo "ECR Scan Report: Critical & High severity vulnerability found in the image $ecr_repo. Number of critical vulnerability = $critical_sev and high vulnerability = $high_sev.";
        else
        echo "ECR Scan Report: Critical severity vulnerability found in the image $ecr_repo. Number of vulnerability = $critical_sev.";
        fi
    elif [ "$high_sev" > "0" ];
    then
        echo "ECR Scan Report: High severity vulnerability found in the image $ecr_repo. Number of vulnerability = $high_sev.";
    else
        echo "ECR Scan Report: No Critial or High severity vulnerability found in the image $ecr_repo.";
    fi

    aws ecr get-login-password --region us-west-2 --profile devcicd | docker login --username AWS --password-stdin 155880749572.dkr.ecr.us-west-2.amazonaws.com
    ecr_repo=$(echo $images | sed 's/^.\{45\}//')
    echo "ECR Repo is $ecr_repo"
    repo_name=$(echo $ecr_repo | cut -d':' -f1)
    echo "Repo name is $repo_name"
    tag_name=$(echo $ecr_repo | cut -d':' -f2)
    echo $tag_name
    tags_in_source=$(aws ecr --region us-west-2 --profile devcicd list-images --repository-name $repo_name  | jq -r 'map(.[] | .imageTag) | join(" ")') || true
    echo "Tags available in the Source account ECR Repo - $tags_in_source."      
    aws ecr get-login-password --region us-west-2 --profile centralcicd | docker login --username AWS --password-stdin 842297555285.dkr.ecr.us-west-2.amazonaws.com
    check_repo_exists=$(aws ecr --region us-west-2 --profile centralcicd describe-repositories  | grep .repositoryName | grep $repo_name | awk '{print $2}'| sed 's/"//g'  | sed 's/,//g')
    echo "Checking if repo exists $check_repo_exists"
    tags_in_target=$(aws ecr --region us-west-2 --profile centralcicd list-images --repository-name $repo_name  | jq -r 'map(.[] | .imageTag) | join(" ")') || true
    echo "Tags available in the Target account ECR Repo - $tags_in_target."
    if [ "$check_repo_exists" = "$repo_name" ];
    then
        echo "ECR Repo exists $check_repo_exists."
        for i in $tags_in_source; do
        for j in $tags_in_target; do
            if [ $j = $tag_name ];
            then
            echo "Image is found in Target ECR $check_repo_exists:$tag_name. No action will be taken";
            break;
            elif [ $i = $tag_name ];
            then
        echo "Image is not available in Target ECR. Push $check_repo_exists:$tag_name";
        aws ecr get-login-password --region us-west-2 --profile devcicd  | docker login --username AWS --password-stdin 155880749572.dkr.ecr.us-west-2.amazonaws.com
        docker pull $images
        docker tag $images $cicd_central_account.dkr.ecr.us-west-2.amazonaws.com/$check_repo_exists:$tag_name
        aws ecr get-login-password --region us-west-2 --profile centralcicd | docker login --username AWS --password-stdin 842297555285.dkr.ecr.us-west-2.amazonaws.com
        docker push $cicd_central_account.dkr.ecr.us-west-2.amazonaws.com/$check_repo_exists:$tag_name
        break;
        else
            echo "Image is already available in Target ECR. Nothing to do"
        fi
        done
        done
    else
        echo "ECR Repo does not exist for the repository $repo_name. Create ECR Repo and push the image"
        aws ecr get-login-password --region us-west-2 --profile devcicd | docker login --username AWS --password-stdin 155880749572.dkr.ecr.us-west-2.amazonaws.com
        docker pull $images
        docker tag $images $cicd_central_account.dkr.ecr.us-west-2.amazonaws.com/$repo_name:$tag_name
        aws ecr get-login-password --region us-west-2 --profile centralcicd | docker login --username AWS --password-stdin 842297555285.dkr.ecr.us-west-2.amazonaws.com
        aws ecr create-repository --profile centralcicd --repository-name $repo_name --tags Key=dish:deployment:isv-name,Value=$ISV_NAME || true
        aws ecr set-repository-policy --region us-west-2 --profile centralcicd --repository-name $repo_name --policy-text file://ecr_image_policy.json
        docker push $cicd_central_account.dkr.ecr.us-west-2.amazonaws.com/$repo_name:$tag_name
    fi
done

if [ $ISV_NAME == nk ]; then
  rm -rf Dish-CDK-Modules
fi