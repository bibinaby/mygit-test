Add Production Configuration here to create prod infrastructure
